package com.kh.test.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.test.model.vo.Member;

@Repository
public class MemberDAO {
	
	@Autowired
	private SqlSessionTemplate sqlSession;
	
	public int registerMember(Member vo) {
		return sqlSession.insert("memberMapper.registerMember", vo);
	}
	
	
	public List<Member> showAllMember() {
		return sqlSession.selectList("memberMapper.showAllMember");
	}
	
	public List<Member> findMember(String keyword) {
		return sqlSession.selectOne("memberMapper.findMember", keyword);
	}
	
	public Member login(Member vo) {
		return sqlSession.selectOne("memberMapper.login", vo);
	}
	
	public int updateMember(Member vo) {
		return sqlSession.update("memberMapper.updateMember", vo);
	}

}
